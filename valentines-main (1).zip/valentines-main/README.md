# 💌 Valentine's Day App 💌

## About
A simple application to ask your friends and family to be your Valentine :-). Enjoy 💖!

## Getting Started
In the project directory, you can: 

1. Fork the repo
2. Run `npm run dev`

Open [http://localhost:3000](http://localhost:3000) to view it in your browser.
